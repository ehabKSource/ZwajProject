import { LangDirective } from './lang.directive';

describe('LangDirective', () => {
  it('should create an instance', () => {
    const directive = new LangDirective();
    expect(directive).toBeTruthy();
  });
});
