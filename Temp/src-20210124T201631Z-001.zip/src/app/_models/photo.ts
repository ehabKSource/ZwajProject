export interface Photo {
    id:number;
    url:string;
    dateAdded:Date;
    isMain:boolean;
    isApproved:boolean;
    
}
